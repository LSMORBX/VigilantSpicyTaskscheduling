document.querySelector('.join-game-instant').addEventListener('click', () => {
    window.open('https://game.bronzeforever.net/', '_blank');
});